# ioBroker.mobilealerts
Adapter für ioBroker, um Daten von Mobile Alerts auszulesen.
## Funktionen
- 🌡️ Temperatur
- 💧 Luftfeuchtigkeit
- 🔋 Batteriestatus
- 🕒 Zeitstempel
## Installation
1. Auf GitHub hochladen oder ZIP importieren.
2. In ioBroker als eigene Quelle hinzufügen.
3. PhoneID & Intervall konfigurieren.
